#!/usr/bin/env bash
# Adds the HotelPro documentation to your repo and pushes it to GitHub.
# Usage: run this from the folder that contains README.md and documentation/
set -e

REPO_URL="https://github.com/noa-he/Hotelpro.git"
WORKDIR="Hotelpro-push"

git clone "$REPO_URL" "$WORKDIR"
cp -r documentation "$WORKDIR"/
cp README.md "$WORKDIR"/README.md      # replaces the old README (fixes the clone and npm start instructions)

cd "$WORKDIR"
git add documentation README.md
git commit -m "Add phase-wise project documentation and update README"
git push origin main

echo "Done. Check https://github.com/noa-he/Hotelpro"
