# HotelPro

A full-stack hotel management web application. Guests search and book rooms, staff confirm bookings and handle check-in and check-out, and admins manage rooms. Availability updates live across browsers.

**Live demo:** https://hotelpro-chi.vercel.app

## Features

- Room search by dates, guests, room type and price
- Live availability check with the list of already-booked dates
- Booking with server-calculated price and double-booking protection
- Guest, staff and admin roles
- Staff dashboard: confirm, check in, check out, cancel
- Real-time updates with Socket.IO
- Responsive, colour-themed interface

## Tech stack

React 18 · Vite · React Router · Bootstrap 5 · Node.js · Express · MongoDB (Mongoose) · Socket.IO · JWT · bcrypt

## Project structure

```
HotelPro/
├── client/          React frontend
├── server/          Express API, models, sockets
├── documentation/   Phase-wise and technical documentation
└── README.md
```

## Getting started

Requirements: Node.js 18+, MongoDB (local or Atlas).

```bash
git clone https://github.com/noa-he/Hotelpro.git
cd Hotelpro
```

**Backend**

```bash
cd server
cp .env.example .env      # then edit the values
npm install
npm run seed              # demo users and 12 rooms
npm run dev
```

**Frontend** (new terminal)

```bash
cd client
cp .env.example .env
npm install
npm run dev
```

Open http://localhost:5173.

## Demo accounts (after `npm run seed`)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@hotelpro.com | admin123 |
| Staff | staff@hotelpro.com | staff123 |
| Guest | guest@hotelpro.com | guest123 |

Change or remove these before any real deployment.

## Documentation

See the [documentation](documentation/README.md) folder:

1. Ideation Phase
2. Project Planning Phase
3. Requirement Analysis
4. Project Design Phase
5. Performance Testing
6. Technical Documentation (API reference, database, architecture, security, deployment)
